//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Menus.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TPoints : public TForm
{
__published:	// IDE-managed Components
        TTimer *Timer1;
        TButton *Button2;
        TButton *Button3;
        TPanel *Panel1;
        TPanel *Panel2;
        TPanel *Panel3;
        TPanel *Panel4;
        TPanel *Panel5;
        TPanel *Panel6;
        TButton *Button4;
        TPanel *Panel7;
        TPanel *Panel8;
        TPanel *Panel9;
        TButton *Button6;
        TButton *Button1;
        TButton *Button9;
        TPanel *Panel10;
        TPanel *Panel11;
        TComboBox *ComboBox1;
        TPanel *Panel83;
        TGroupBox *GroupBox2;
        TLabel *Label47;
        TLabel *Label48;
        TPanel *Panel84;
        TSpeedButton *SpeedButton1;
        TLabel *Label2;
        TLabel *Label3;
        TLabel *Label1;
        void __fastcall Button1Click(TObject *Sender);
        void __fastcall Timer1Timer(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall Button2Click(TObject *Sender);
        void __fastcall Button3Click(TObject *Sender);
        void __fastcall Button6Click(TObject *Sender);
        void __fastcall Button9Click(TObject *Sender);
        void __fastcall Panel3MouseDown(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y);
        void __fastcall Panel2MouseDown(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y);
        void __fastcall Panel4MouseDown(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y);
        void __fastcall Panel1MouseDown(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y);
        void __fastcall FormPaint(TObject *Sender);
        void __fastcall Button4Click(TObject *Sender);
        void __fastcall Panel10Click(TObject *Sender);
        void __fastcall Panel11Click(TObject *Sender);
        void __fastcall Panel10MouseDown(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y);
        void __fastcall Panel10MouseUp(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y);
        void __fastcall Panel11MouseDown(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y);
        void __fastcall Panel11MouseUp(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y);
        void __fastcall ComboBox1Change(TObject *Sender);
        void __fastcall SpeedButton1Click(TObject *Sender);
        void __fastcall Panel84Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TPoints(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TPoints *Points;
//---------------------------------------------------------------------------
#endif
